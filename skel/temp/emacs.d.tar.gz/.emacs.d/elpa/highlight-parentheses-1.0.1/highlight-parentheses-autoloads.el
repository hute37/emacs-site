;;; highlight-parentheses-autoloads.el --- automatically extracted autoloads
;;
;;; Code:


;;;### (autoloads (highlight-parentheses-mode) "highlight-parentheses"
;;;;;;  "highlight-parentheses.el" (19358 42472))
;;; Generated autoloads from highlight-parentheses.el

(autoload 'highlight-parentheses-mode "highlight-parentheses" "\
Minor mode to highlight the surrounding parentheses.

\(fn &optional ARG)" t nil)

;;;***

;;;### (autoloads nil nil ("highlight-parentheses-pkg.el") (19358
;;;;;;  42472 312000))

;;;***

(provide 'highlight-parentheses-autoloads)
;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; highlight-parentheses-autoloads.el ends here
