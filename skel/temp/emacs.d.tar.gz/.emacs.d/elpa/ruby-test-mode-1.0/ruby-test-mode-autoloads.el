;;; ruby-test-mode-autoloads.el --- automatically extracted autoloads
;;
;;; Code:


;;;### (autoloads (ruby-test-mode) "ruby-test-mode" "ruby-test-mode.el"
;;;;;;  (19353 15329))
;;; Generated autoloads from ruby-test-mode.el

(autoload 'ruby-test-mode "ruby-test-mode" "\
Toggle Ruby-Test minor mode.
With no argument, this command toggles the mode. Non-null prefix
argument turns on the mode. Null prefix argument turns off the
mode.

\(fn &optional ARG)" t nil)

;;;***

;;;### (autoloads nil nil ("ruby-test-mode-pkg.el") (19353 15329
;;;;;;  765000))

;;;***

(provide 'ruby-test-mode-autoloads)
;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; ruby-test-mode-autoloads.el ends here
