;;; slime-repl-autoloads.el --- automatically extracted autoloads
;;
;;; Code:


;;;### (autoloads (slime-repl-init) "slime-repl" "slime-repl.el"
;;;;;;  (19649 32656))
;;; Generated autoloads from slime-repl.el

(autoload 'slime-repl-init "slime-repl" "\
Not documented

\(fn)" nil nil)

(add-hook 'slime-load-hook 'slime-repl-init)

;;;***

;;;### (autoloads nil nil ("slime-repl-pkg.el") (19649 32656 291064))

;;;***

(provide 'slime-repl-autoloads)
;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; slime-repl-autoloads.el ends here
