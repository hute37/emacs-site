(let* ((my-lisp-dir "~/.emacs.d/")
        (default-directory my-lisp-dir))
  (setq load-path (cons my-lisp-dir load-path))
  (normal-top-level-add-subdirs-to-load-path))

(setq frame-title-format "%b")
(column-number-mode t)
(setq inhibit-splash-screen t)

(menu-bar-mode -1)

(when (boundp 'tool-bar-mode)
  (tool-bar-mode -1))
(when (boundp 'scroll-bar-mode)
  (scroll-bar-mode -1))

(fset 'yes-or-no-p 'y-or-n-p)

(transient-mark-mode t)
(delete-selection-mode 1)

(savehist-mode t)

(global-set-key (kbd "RET") 'newline-and-indent)
(global-set-key (kbd "C-z") 'undo)
(global-set-key (kbd "C-q") 'delete-other-windows)
(global-set-key (kbd "C-?") 'comment-or-uncomment-region)
(global-set-key (kbd "C-<f11>") 'slime)

(global-set-key (kbd "<M-left>") 'previous-buffer)
(global-set-key (kbd "<M-right>") 'next-buffer)
(global-set-key (kbd "<M-up>")  'windmove-up)
(global-set-key (kbd "<M-down>")  'windmove-down)

(cua-mode)

(require 'zenburn)
(zenburn)
